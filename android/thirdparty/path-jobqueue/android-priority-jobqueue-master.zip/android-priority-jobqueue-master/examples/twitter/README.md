**build and run**
gradle installDebug runTwitter