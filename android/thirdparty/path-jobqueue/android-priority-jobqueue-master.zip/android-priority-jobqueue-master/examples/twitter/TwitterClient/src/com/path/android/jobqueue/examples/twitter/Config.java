package com.path.android.jobqueue.examples.twitter;

public class Config {
    public static final String CONSUMER_KEY = "APEGHy66BMYzvgEktDfc1Q";
    public static final String CONSUMER_SECRET = "wf8XXYwivxHQtiIqPSD3lpq6po9JGRyYBIX0lT0";

    public static final String ACCESS_TOKEN = "1443060589-ZW0lPmcN0NOwy2AchLjZjixHLhPXClYOPQ0IhWG";
    public static final String ACCESS_TOKEN_SECRET = "Tq8aVvT1PA6PXtKHgI5v1EL5UQj3JcGlFzXla2zethjYO";

    public static final String REQUEST_TOKEN_URL = "https://api.twitter.com/oauth/request_token";
    public static final String AUTHORIZE_URL = "https://api.twitter.com/oauth/authorize";
    public static final String ACCESS_TOKEN_URL = "https://api.twitter.com/oauth/access_token";
}
