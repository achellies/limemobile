package com.path.android.jobqueue.examples.twitter.events;

public class FetchedNewTweetsEvent {
}
