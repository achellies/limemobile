# fastjson

Fast JSON Processor

![](logo.jpg)

## Documentation
https://github.com/alibaba/fastjson/wiki/%E5%B8%B8%E8%A7%81%E9%97%AE%E9%A2%98

## Benchmark
https://github.com/eishay/jvm-serializers/wiki


## Download
http://repo1.maven.org/maven2/com/alibaba/fastjson/


## Maven

    <dependency>
        <groupId>com.alibaba</groupId>
        <artifactId>fastjson</artifactId>
        <version>x.x.x</version>
    </dependency>
    
